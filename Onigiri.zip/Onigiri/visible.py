


layers = {}

layers["base"] = 1
layers["volume"] = 2
layers["attach"] = 3
layers["attach2"] = 4
layers["hind"] = 5
layers["face"] = 6
layers["hand"] = 7
layers["wing"] = 8
layers["tail"] = 9
layers["spine"] = 10


layers["groin"] = 1 

default = {'base', 'hand'}



layers["base"] = 0
layers["volume"] = 0
layers["attach"] = 0
layers["attach2"] = 0
layers["hind"] = 0
layers["face"] = 0
layers["hand"] = 0
layers["wing"] = 0
layers["tail"] = 0
layers["spine"] = 0
layers["groin"] = 0



bones = {}
bones["base"] = {
    'mKneeRight', 'mAnkleRight', 'mGroin', 'mHipRight',
    'mAnkleLeft', 'mFootLeft', 'mChest', 'mElbowLeft',
    'mShoulderRight', 'mEyeLeft', 'mFootRight',
    'mCollarLeft', 'mKneeLeft', 'mSkull', 'mWristLeft',
    'mToeRight', 'mEyeRight', 'mElbowRight', 'mTorso',
    'mShoulderLeft', 'mNeck', 'mCollarRight', 'mHipLeft',
    'mHead', 'mPelvis', 'mWristRight', 'mToeLeft'
    }
























