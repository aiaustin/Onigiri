https://github.com/nessaki/Onigiri

This was made for everyone who wants to rig things for secondlife.
It is covered under GPLv3.




